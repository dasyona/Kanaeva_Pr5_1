package com.example.pogoda_kanaeva

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private val apiKey = "49da4bb0f9966e7669deac043cdb2dd7"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val cityInput = findViewById<EditText>(R.id.cityInput)
        val searchButton = findViewById<Button>(R.id.searchButton)
        val tvCity = findViewById<TextView>(R.id.tvCity)
        val tvTemp = findViewById<TextView>(R.id.tvTemp)
        val tvPressure = findViewById<TextView>(R.id.tvPressure)
        val tvWind = findViewById<TextView>(R.id.tvWind)


        searchButton.setOnClickListener {
            val city = cityInput.text.toString().trim()
            if (city.isNotEmpty()) {
                getWeather(city, tvCity, tvTemp, tvPressure, tvWind)
            } else {
                Toast.makeText(this, "Введите название города", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Функция для получения данных с API
    private fun getWeather(city: String, tvCity: TextView, tvTemp: TextView, tvPressure: TextView, tvWind: TextView) {
        // Формируем URL
        val url = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric&lang=ru"


        val queue = Volley.newRequestQueue(this)


        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->
                // Этот блок выполняется, если сервер ответил успешно
                try {

                    val obj = JSONObject(response)


                    val name = obj.getString("name")
                    val mainObj = obj.getJSONObject("main")
                    val temp = mainObj.getDouble("temp")
                    val pressure = mainObj.getDouble("pressure")

                    val windObj = obj.getJSONObject("wind")
                    val windSpeed = windObj.getDouble("speed")

                    // Выводим в Logcat
                    Log.d("MyLog", "Город: $name, Температура: $temp")

                    // Обновляем текст на экране
                    tvCity.text = "Город: $name"
                    tvTemp.text = "Температура: $temp °C"

                    tvPressure.text = "Давление: ${(pressure / 1.333).toInt()} мм рт. ст."
                    tvWind.text = "Ветер: $windSpeed м/с"

                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(this, "Ошибка при чтении данных", Toast.LENGTH_SHORT).show()
                }
            },
            { error ->
                // Этот блок выполняется при ошибке
                Log.e("MyLog", "Ошибка: ${error.message}")
                Toast.makeText(this, "Город не найден или ошибка сети", Toast.LENGTH_SHORT).show()
            }
        )


        queue.add(stringRequest)
    }
}